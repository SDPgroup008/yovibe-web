import { View, Text, StyleSheet } from "react-native"

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>YoVibe Test App</Text>
      <Text style={styles.subtext}>If you can see this, the app is working!</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
    alignItems: "center",
    justifyContent: "center",
  },
  text: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
  },
  subtext: {
    fontSize: 16,
    color: "#BBBBBB",
  },
})
