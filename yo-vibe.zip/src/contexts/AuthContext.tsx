"use client"

import type React from "react"
import { createContext, useState, useEffect, useContext } from "react"
import { onAuthStateChanged } from "firebase/auth"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { auth } from "../config/firebase"
import FirebaseService from "../services/FirebaseService"
import type { User, UserType } from "../models/User"

interface AuthContextType {
  user: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, userType: UserType) => Promise<void>
  signOut: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Key for storing user data in AsyncStorage
const USER_STORAGE_KEY = "yovibe_user_data"

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Load user from AsyncStorage on initial load
  useEffect(() => {
    const loadStoredUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem(USER_STORAGE_KEY)
        if (storedUser) {
          setUser(JSON.parse(storedUser))
        }
      } catch (error) {
        console.error("Error loading stored user:", error)
      } finally {
        setLoading(false)
      }
    }

    loadStoredUser()
  }, [])

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true)

      if (firebaseUser) {
        try {
          const userProfile = await FirebaseService.getUserProfile(firebaseUser.uid)
          setUser(userProfile)

          // Store user data in AsyncStorage
          await AsyncStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userProfile))
        } catch (error) {
          console.error("Error fetching user profile:", error)
          setUser(null)
          await AsyncStorage.removeItem(USER_STORAGE_KEY)
        }
      } else {
        setUser(null)
        await AsyncStorage.removeItem(USER_STORAGE_KEY)
      }

      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    setLoading(true)
    try {
      await FirebaseService.signIn(email, password)
      // The onAuthStateChanged listener will update the user state
    } catch (error) {
      console.error("Error signing in:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const signUp = async (email: string, password: string, userType: UserType) => {
    setLoading(true)
    try {
      await FirebaseService.signUp(email, password, userType)
      // The onAuthStateChanged listener will update the user state
    } catch (error) {
      console.error("Error signing up:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    setLoading(true)
    try {
      await FirebaseService.signOut()
      // Clear stored user data
      await AsyncStorage.removeItem(USER_STORAGE_KEY)
      setUser(null)
    } catch (error) {
      console.error("Error signing out:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async (data: Partial<User>) => {
    if (!user) {
      throw new Error("No user logged in")
    }

    setLoading(true)
    try {
      await FirebaseService.updateUserProfile(user.id, data)

      // Update local user state
      const updatedUser = { ...user, ...data }
      setUser(updatedUser)

      // Update stored user data
      await AsyncStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updatedUser))
    } catch (error) {
      console.error("Error updating profile:", error)
      throw error
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, updateProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
