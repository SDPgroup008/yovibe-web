// Import all polyfills and initialization code here
import "react-native-get-random-values"

// This file doesn't export anything, it just runs the code
console.log("Polyfills and initialization complete")
