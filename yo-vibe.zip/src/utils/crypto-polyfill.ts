// Polyfill for crypto.getRandomValues
import "react-native-get-random-values"

// This import is necessary to ensure the polyfill is loaded before any UUID operations
