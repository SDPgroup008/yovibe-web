import "react-native-get-random-values" // Add this import at the top
import {
  collection,
  addDoc,
  getDoc,
  getDocs,
  doc,
  query,
  where,
  updateDoc,
  deleteDoc,
  Timestamp,
} from "firebase/firestore"
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut as firebaseSignOut } from "firebase/auth"
import { ref, uploadBytes, getDownloadURL } from "firebase/storage"
import { auth, db, storage } from "../config/firebase"
import type { User, UserType } from "../models/User"
import type { Venue } from "../models/Venue"
import type { Event } from "../models/Event"
import { v4 as uuidv4 } from "uuid"

class FirebaseService {
  // Auth methods
  async signUp(email: string, password: string, userType: UserType): Promise<void> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const { uid } = userCredential.user

      // Create user profile in Firestore
      const userRef = await addDoc(collection(db, "users"), {
        uid,
        email,
        userType,
        createdAt: Timestamp.now(),
        lastLoginAt: Timestamp.now(),
      })

      return
    } catch (error) {
      console.error("Error signing up:", error)
      throw error
    }
  }

  async signIn(email: string, password: string): Promise<void> {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      return
    } catch (error) {
      console.error("Error signing in:", error)
      throw error
    }
  }

  async signOut(): Promise<void> {
    try {
      await firebaseSignOut(auth)
      return
    } catch (error) {
      console.error("Error signing out:", error)
      throw error
    }
  }

  // User methods
  async getUserProfile(uid: string): Promise<User> {
    try {
      const usersRef = collection(db, "users")
      const q = query(usersRef, where("uid", "==", uid))
      const querySnapshot = await getDocs(q)

      if (querySnapshot.empty) {
        throw new Error("User not found")
      }

      const userDoc = querySnapshot.docs[0]
      const userData = userDoc.data()

      return {
        id: userDoc.id,
        uid: userData.uid,
        email: userData.email,
        userType: userData.userType,
        displayName: userData.displayName,
        photoURL: userData.photoURL,
        venueId: userData.venueId,
        createdAt: userData.createdAt.toDate(),
        lastLoginAt: userData.lastLoginAt.toDate(),
      }
    } catch (error) {
      console.error("Error getting user profile:", error)
      throw error
    }
  }

  async getCurrentUser(): Promise<User | null> {
    try {
      const currentUser = auth.currentUser
      if (!currentUser) {
        return null
      }

      return await this.getUserProfile(currentUser.uid)
    } catch (error) {
      console.error("Error getting current user:", error)
      throw error
    }
  }

  async updateUserProfile(userId: string, data: Partial<User>): Promise<void> {
    try {
      const userRef = doc(db, "users", userId)
      await updateDoc(userRef, data)
      return
    } catch (error) {
      console.error("Error updating user profile:", error)
      throw error
    }
  }

  // Venue methods
  async getVenues(): Promise<Venue[]> {
    try {
      const venuesRef = collection(db, "venues")
      const querySnapshot = await getDocs(venuesRef)
      const venues: Venue[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        venues.push({
          id: doc.id,
          name: data.name,
          location: data.location,
          description: data.description,
          backgroundImageUrl: data.backgroundImageUrl,
          categories: data.categories,
          vibeRating: data.vibeRating,
          todayImages: data.todayImages || [],
          latitude: data.latitude,
          longitude: data.longitude,
          weeklyPrograms: data.weeklyPrograms || {},
          ownerId: data.ownerId,
          createdAt: data.createdAt.toDate(),
        })
      })

      return venues
    } catch (error) {
      console.error("Error getting venues:", error)
      throw error
    }
  }

  async getVenuesByOwner(ownerId: string): Promise<Venue[]> {
    try {
      const venuesRef = collection(db, "venues")
      const q = query(venuesRef, where("ownerId", "==", ownerId))
      const querySnapshot = await getDocs(q)
      const venues: Venue[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        venues.push({
          id: doc.id,
          name: data.name,
          location: data.location,
          description: data.description,
          backgroundImageUrl: data.backgroundImageUrl,
          categories: data.categories,
          vibeRating: data.vibeRating,
          todayImages: data.todayImages || [],
          latitude: data.latitude,
          longitude: data.longitude,
          weeklyPrograms: data.weeklyPrograms || {},
          ownerId: data.ownerId,
          createdAt: data.createdAt.toDate(),
        })
      })

      return venues
    } catch (error) {
      console.error("Error getting venues by owner:", error)
      throw error
    }
  }

  async getVenueById(venueId: string): Promise<Venue | null> {
    try {
      const venueRef = doc(db, "venues", venueId)
      const venueDoc = await getDoc(venueRef)

      if (!venueDoc.exists()) {
        return null
      }

      const data = venueDoc.data()
      return {
        id: venueDoc.id,
        name: data.name,
        location: data.location,
        description: data.description,
        backgroundImageUrl: data.backgroundImageUrl,
        categories: data.categories,
        vibeRating: data.vibeRating,
        todayImages: data.todayImages || [],
        latitude: data.latitude,
        longitude: data.longitude,
        weeklyPrograms: data.weeklyPrograms || {},
        ownerId: data.ownerId,
        createdAt: data.createdAt.toDate(),
      }
    } catch (error) {
      console.error("Error getting venue by ID:", error)
      throw error
    }
  }

  async addVenue(venueData: Omit<Venue, "id">): Promise<string> {
    try {
      const venueRef = await addDoc(collection(db, "venues"), {
        ...venueData,
        createdAt: Timestamp.fromDate(venueData.createdAt),
      })

      return venueRef.id
    } catch (error) {
      console.error("Error adding venue:", error)
      throw error
    }
  }

  async updateVenue(venueId: string, data: Partial<Venue>): Promise<void> {
    try {
      const venueRef = doc(db, "venues", venueId)
      await updateDoc(venueRef, data)
      return
    } catch (error) {
      console.error("Error updating venue:", error)
      throw error
    }
  }

  async updateVenuePrograms(venueId: string, programs: Record<string, string>): Promise<void> {
    try {
      const venueRef = doc(db, "venues", venueId)
      await updateDoc(venueRef, { weeklyPrograms: programs })
      return
    } catch (error) {
      console.error("Error updating venue programs:", error)
      throw error
    }
  }

  async deleteVenue(venueId: string): Promise<void> {
    try {
      const venueRef = doc(db, "venues", venueId)
      await deleteDoc(venueRef)
      return
    } catch (error) {
      console.error("Error deleting venue:", error)
      throw error
    }
  }

  // Event methods
  async getEvents(): Promise<Event[]> {
    try {
      const eventsRef = collection(db, "events")
      const querySnapshot = await getDocs(eventsRef)
      const events: Event[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        events.push({
          id: doc.id,
          name: data.name,
          venueId: data.venueId,
          venueName: data.venueName,
          description: data.description,
          date: data.date.toDate(),
          posterImageUrl: data.posterImageUrl,
          artists: data.artists,
          isFeatured: data.isFeatured,
          createdAt: data.createdAt.toDate(),
          createdBy: data.createdBy,
          createdByType: data.createdByType,
        })
      })

      return events
    } catch (error) {
      console.error("Error getting events:", error)
      throw error
    }
  }

  async getFeaturedEvents(): Promise<Event[]> {
    try {
      const eventsRef = collection(db, "events")
      const q = query(eventsRef, where("isFeatured", "==", true))
      const querySnapshot = await getDocs(q)
      const events: Event[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        events.push({
          id: doc.id,
          name: data.name,
          venueId: data.venueId,
          venueName: data.venueName,
          description: data.description,
          date: data.date.toDate(),
          posterImageUrl: data.posterImageUrl,
          artists: data.artists,
          isFeatured: data.isFeatured,
          createdAt: data.createdAt.toDate(),
          createdBy: data.createdBy,
          createdByType: data.createdByType,
        })
      })

      return events
    } catch (error) {
      console.error("Error getting featured events:", error)
      throw error
    }
  }

  async getEventsByVenue(venueId: string): Promise<Event[]> {
    try {
      const eventsRef = collection(db, "events")
      const q = query(eventsRef, where("venueId", "==", venueId))
      const querySnapshot = await getDocs(q)
      const events: Event[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        events.push({
          id: doc.id,
          name: data.name,
          venueId: data.venueId,
          venueName: data.venueName,
          description: data.description,
          date: data.date.toDate(),
          posterImageUrl: data.posterImageUrl,
          artists: data.artists,
          isFeatured: data.isFeatured,
          createdAt: data.createdAt.toDate(),
          createdBy: data.createdBy,
          createdByType: data.createdByType,
        })
      })

      return events
    } catch (error) {
      console.error("Error getting events by venue:", error)
      throw error
    }
  }

  async getEventById(eventId: string): Promise<Event | null> {
    try {
      const eventRef = doc(db, "events", eventId)
      const eventDoc = await getDoc(eventRef)

      if (!eventDoc.exists()) {
        return null
      }

      const data = eventDoc.data()
      return {
        id: eventDoc.id,
        name: data.name,
        venueId: data.venueId,
        venueName: data.venueName,
        description: data.description,
        date: data.date.toDate(),
        posterImageUrl: data.posterImageUrl,
        artists: data.artists,
        isFeatured: data.isFeatured,
        createdAt: data.createdAt.toDate(),
        createdBy: data.createdBy,
        createdByType: data.createdByType,
      }
    } catch (error) {
      console.error("Error getting event by ID:", error)
      throw error
    }
  }

  async addEvent(eventData: Omit<Event, "id">): Promise<string> {
    try {
      // Create a Firestore-compatible object with type assertion
      const firestoreEventData = {
        name: eventData.name,
        venueId: eventData.venueId,
        venueName: eventData.venueName,
        description: eventData.description,
        date: Timestamp.fromDate(eventData.date) as any, // Use type assertion to avoid TypeScript error
        posterImageUrl: eventData.posterImageUrl,
        artists: eventData.artists,
        isFeatured: eventData.isFeatured,
        createdAt: Timestamp.fromDate(new Date()) as any, // Use type assertion to avoid TypeScript error
        createdBy: eventData.createdBy,
        createdByType: eventData.createdByType,
      }

      // Add the document to Firestore
      const eventRef = await addDoc(collection(db, "events"), firestoreEventData)

      return eventRef.id
    } catch (error) {
      console.error("Error adding event:", error)
      throw error
    }
  }

  async updateEvent(eventId: string, data: Partial<Event>): Promise<void> {
    try {
      const eventRef = doc(db, "events", eventId)

      // Convert Date objects to Firestore Timestamps
      const firestoreData: any = { ...data }
      if (data.date) {
        firestoreData.date = Timestamp.fromDate(data.date)
      }

      await updateDoc(eventRef, firestoreData)
      return
    } catch (error) {
      console.error("Error updating event:", error)
      throw error
    }
  }

  async deleteEvent(eventId: string): Promise<void> {
    try {
      const eventRef = doc(db, "events", eventId)
      await deleteDoc(eventRef)
      return
    } catch (error) {
      console.error("Error deleting event:", error)
      throw error
    }
  }

  // Image upload methods
  async uploadVenueImage(uri: string): Promise<string> {
    try {
      const response = await fetch(uri)
      const blob = await response.blob()
      const filename = `venues/${uuidv4()}`
      const storageRef = ref(storage, filename)

      await uploadBytes(storageRef, blob)
      const downloadURL = await getDownloadURL(storageRef)

      return downloadURL
    } catch (error) {
      console.error("Error uploading venue image:", error)
      throw error
    }
  }

  async uploadEventImage(uri: string): Promise<string> {
    try {
      const response = await fetch(uri)
      const blob = await response.blob()
      const filename = `events/${uuidv4()}`
      const storageRef = ref(storage, filename)

      await uploadBytes(storageRef, blob)
      const downloadURL = await getDownloadURL(storageRef)

      return downloadURL
    } catch (error) {
      console.error("Error uploading event image:", error)
      throw error
    }
  }

  // Admin methods
  async getAllUsers(): Promise<User[]> {
    try {
      const usersRef = collection(db, "users")
      const querySnapshot = await getDocs(usersRef)
      const users: User[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        users.push({
          id: doc.id,
          uid: data.uid,
          email: data.email,
          userType: data.userType,
          displayName: data.displayName,
          photoURL: data.photoURL,
          venueId: data.venueId,
          createdAt: data.createdAt.toDate(),
          lastLoginAt: data.lastLoginAt.toDate(),
        })
      })

      return users
    } catch (error) {
      console.error("Error getting all users:", error)
      throw error
    }
  }

  async getClubOwners(): Promise<User[]> {
    try {
      const usersRef = collection(db, "users")
      const q = query(usersRef, where("userType", "==", "club_owner"))
      const querySnapshot = await getDocs(q)
      const users: User[] = []

      querySnapshot.forEach((doc) => {
        const data = doc.data()
        users.push({
          id: doc.id,
          uid: data.uid,
          email: data.email,
          userType: data.userType,
          displayName: data.displayName,
          photoURL: data.photoURL,
          venueId: data.venueId,
          createdAt: data.createdAt.toDate(),
          lastLoginAt: data.lastLoginAt.toDate(),
        })
      })

      return users
    } catch (error) {
      console.error("Error getting club owners:", error)
      throw error
    }
  }

  async freezeUser(userId: string, isFrozen: boolean): Promise<void> {
    try {
      const userRef = doc(db, "users", userId)
      await updateDoc(userRef, { isFrozen })
      return
    } catch (error) {
      console.error("Error freezing/unfreezing user:", error)
      throw error
    }
  }

  async deleteUser(userId: string): Promise<void> {
    try {
      const userRef = doc(db, "users", userId)
      await deleteDoc(userRef)
      return
    } catch (error) {
      console.error("Error deleting user:", error)
      throw error
    }
  }
}

export default new FirebaseService()
