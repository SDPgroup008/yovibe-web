// Mock for the problematic native module
export default {}
