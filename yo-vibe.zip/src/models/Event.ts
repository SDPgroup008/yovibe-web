import type { Timestamp } from "firebase/firestore"
import type { UserType } from "./User"

export interface Event {
  id: string
  name: string
  venueId: string
  venueName: string
  description: string
  date: Date
  posterImageUrl: string
  artists: string[]
  isFeatured: boolean
  createdAt: Date
  createdBy?: string
  createdByType?: UserType
}

// Add a new interface for Firestore storage
export interface FirestoreEvent {
  name: string
  venueId: string
  venueName: string
  description: string
  date: Timestamp
  posterImageUrl: string
  artists: string[]
  isFeatured: boolean
  createdAt: Timestamp
  createdBy?: string
  createdByType?: UserType
}
