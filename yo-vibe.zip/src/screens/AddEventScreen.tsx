"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Image, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import FirebaseService from "../services/FirebaseService"
import { useAuth } from "../contexts/AuthContext"

interface AddEventScreenProps {
  navigation: any
  route: {
    params?: {
      venueId?: string
      venueName?: string
    }
  }
}

const AddEventScreen: React.FC<AddEventScreenProps> = ({ navigation, route }) => {
  const { user } = useAuth()
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState(new Date())
  const [dateString, setDateString] = useState(new Date().toISOString().split("T")[0])
  const [artists, setArtists] = useState("")
  const [image, setImage] = useState<string | null>(null)
  const [isFeatured, setIsFeatured] = useState(false)
  const [loading, setLoading] = useState(false)
  const [venues, setVenues] = useState<Array<{ id: string; name: string }>>([])
  const [selectedVenueId, setSelectedVenueId] = useState(route.params?.venueId || "")
  const [selectedVenueName, setSelectedVenueName] = useState(route.params?.venueName || "")
  const [showVenueSelector, setShowVenueSelector] = useState(false)

  useEffect(() => {
    // If user is not a club owner, load venues for selection
    if (user && user.userType !== "club_owner") {
      loadVenues()
    }
  }, [user])

  const loadVenues = async () => {
    try {
      const venuesList = await FirebaseService.getVenues()
      setVenues(venuesList.map((venue) => ({ id: venue.id, name: venue.name })))
    } catch (error) {
      console.error("Error loading venues:", error)
    }
  }

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDate = new Date(e.target.value)
    setDate(newDate)
    setDateString(e.target.value)
  }

  const handleVenueSelect = (venueId: string, venueName: string) => {
    setSelectedVenueId(venueId)
    setSelectedVenueName(venueName)
    setShowVenueSelector(false)
  }

  const handleSubmit = async () => {
    if (!name || !description || !artists) {
      Alert.alert("Error", "Please fill in all required fields")
      return
    }

    if (!image) {
      Alert.alert("Error", "Please enter an image URL for the event")
      return
    }

    if (!selectedVenueId) {
      Alert.alert("Error", "Please select a venue for this event")
      return
    }

    if (!user) {
      Alert.alert("Error", "You must be logged in to add an event")
      return
    }

    setLoading(true)

    try {
      // Upload image first
      const imageUrl = await FirebaseService.uploadEventImage(image)

      // Create event object
      const eventData = {
        name,
        description,
        date,
        artists: artists.split(",").map((artist) => artist.trim()),
        venueId: selectedVenueId,
        venueName: selectedVenueName,
        posterImageUrl: imageUrl,
        isFeatured,
        createdAt: new Date(),
        createdBy: user.id,
        createdByType: user.userType,
      }

      // Add event to database
      await FirebaseService.addEvent(eventData)

      Alert.alert("Success", "Event created successfully")
      navigation.goBack()
    } catch (error) {
      Alert.alert("Error", "Failed to create event")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.form}>
        <Text style={styles.label}>Event Name *</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Enter event name"
          placeholderTextColor="#999"
        />

        <Text style={styles.label}>Description *</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          value={description}
          onChangeText={setDescription}
          placeholder="Enter event description"
          placeholderTextColor="#999"
          multiline
          numberOfLines={4}
        />

        <Text style={styles.label}>Event Date *</Text>
        <View style={styles.datePickerContainer}>
          <input
            type="date"
            value={dateString}
            onChange={handleDateChange}
            style={{
              backgroundColor: "#1E1E1E",
              color: "#FFFFFF",
              padding: "12px",
              borderRadius: "8px",
              border: "1px solid #333",
              width: "100%",
              marginBottom: "16px",
            }}
          />
        </View>

        <Text style={styles.label}>Artists *</Text>
        <TextInput
          style={styles.input}
          value={artists}
          onChangeText={setArtists}
          placeholder="Enter artists (comma separated)"
          placeholderTextColor="#999"
        />

        {/* Venue selection for regular users */}
        {user?.userType !== "club_owner" && (
          <>
            <Text style={styles.label}>Venue *</Text>
            <TouchableOpacity style={styles.venueSelector} onPress={() => setShowVenueSelector(!showVenueSelector)}>
              <Text style={styles.venueSelectorText}>{selectedVenueName || "Select a venue"}</Text>
              <Ionicons name={showVenueSelector ? "chevron-up" : "chevron-down"} size={24} color="#FFFFFF" />
            </TouchableOpacity>

            {showVenueSelector && (
              <View style={styles.venueDropdown}>
                <ScrollView style={styles.venueList} nestedScrollEnabled>
                  {venues.map((venue) => (
                    <TouchableOpacity
                      key={venue.id}
                      style={styles.venueItem}
                      onPress={() => handleVenueSelect(venue.id, venue.name)}
                    >
                      <Text style={styles.venueItemText}>{venue.name}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            )}
          </>
        )}

        {/* For club owners, show the selected venue */}
        {user?.userType === "club_owner" && (
          <>
            <Text style={styles.label}>Venue</Text>
            <View style={styles.venueInfo}>
              <Text style={styles.venueText}>{selectedVenueName || "No venue selected"}</Text>
            </View>
          </>
        )}

        {/* Feature toggle (only for admins) */}
        {user?.userType === "admin" && (
          <View style={styles.checkboxContainer}>
            <TouchableOpacity style={styles.checkbox} onPress={() => setIsFeatured(!isFeatured)}>
              {isFeatured ? (
                <Ionicons name="checkbox" size={24} color="#2196F3" />
              ) : (
                <Ionicons name="square-outline" size={24} color="#FFFFFF" />
              )}
            </TouchableOpacity>
            <Text style={styles.checkboxLabel}>Feature this event</Text>
          </View>
        )}

        <Text style={styles.label}>Event Poster URL *</Text>
        <TextInput
          style={styles.input}
          value={image || ""}
          onChangeText={setImage}
          placeholder="Enter image URL"
          placeholderTextColor="#999"
        />

        {image && (
          <View style={styles.imagePreview}>
            <Image source={{ uri: image }} style={styles.previewImage} />
          </View>
        )}

        <TouchableOpacity
          style={[styles.submitButton, loading && styles.disabledButton]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <Text style={styles.submitButtonText}>{loading ? "Creating Event..." : "Create Event"}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
  },
  form: {
    padding: 16,
  },
  label: {
    fontSize: 16,
    color: "#FFFFFF",
    marginBottom: 8,
  },
  input: {
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    padding: 12,
    color: "#FFFFFF",
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#333",
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  datePickerContainer: {
    marginBottom: 16,
  },
  venueSelector: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#333",
  },
  venueSelectorText: {
    color: "#FFFFFF",
  },
  venueDropdown: {
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#333",
    maxHeight: 150,
  },
  venueList: {
    padding: 8,
  },
  venueItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#333",
  },
  venueItemText: {
    color: "#FFFFFF",
  },
  venueInfo: {
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#333",
  },
  venueText: {
    color: "#FFFFFF",
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  checkbox: {
    marginRight: 8,
  },
  checkboxLabel: {
    color: "#FFFFFF",
  },
  imagePreview: {
    height: 200,
    marginBottom: 16,
    borderRadius: 8,
    overflow: "hidden",
  },
  previewImage: {
    width: "100%",
    height: "100%",
  },
  submitButton: {
    backgroundColor: "#2196F3",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
  },
  disabledButton: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
  },
})

export default AddEventScreen
