"use client"

import type React from "react"
import { useState } from "react"
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView, ActivityIndicator } from "react-native"
import { useAuth } from "../../contexts/AuthContext"
import type { UserType } from "../../models/User"

interface SignUpScreenProps {
  navigation: any
}

const SignUpScreen: React.FC<SignUpScreenProps> = ({ navigation }) => {
  const { signUp } = useAuth()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [userType, setUserType] = useState<UserType>("user")
  const [loading, setLoading] = useState(false)

  const handleSignUp = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please enter both email and password")
      return
    }

    if (password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters")
      return
    }

    setLoading(true)
    try {
      await signUp(email, password, userType)
      // The AuthContext will handle navigation
    } catch (error) {
      Alert.alert("Sign Up Failed", error instanceof Error ? error.message : "Failed to create account")
    } finally {
      setLoading(false)
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollView}>
      <View style={styles.container}>
        <Text style={styles.title}>Create Account</Text>

        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#999"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />

        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor="#999"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />

        <View style={styles.pickerContainer}>
          <Text style={styles.pickerLabel}>Account Type:</Text>
          <View style={styles.buttonGroup}>
            <TouchableOpacity
              style={[styles.typeButton, userType === "user" && styles.selectedButton]}
              onPress={() => setUserType("user")}
            >
              <Text style={[styles.typeButtonText, userType === "user" && styles.selectedButtonText]}>
                Regular User
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, userType === "club_owner" && styles.selectedButton]}
              onPress={() => setUserType("club_owner")}
            >
              <Text style={[styles.typeButtonText, userType === "club_owner" && styles.selectedButtonText]}>
                Club Owner
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.typeButton, userType === "admin" && styles.selectedButton]}
              onPress={() => setUserType("admin")}
            >
              <Text style={[styles.typeButtonText, userType === "admin" && styles.selectedButtonText]}>Admin</Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity style={styles.button} onPress={handleSignUp} disabled={loading}>
          {loading ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.buttonText}>Sign Up</Text>}
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate("Login")}>
          <Text style={styles.loginText}>Already have an account? Login</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  scrollView: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    padding: 16,
    justifyContent: "center",
    backgroundColor: "#121212",
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    marginBottom: 32,
    color: "#FFFFFF",
    textAlign: "center",
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: "#333",
    borderRadius: 8,
    marginBottom: 16,
    paddingHorizontal: 12,
    backgroundColor: "#1E1E1E",
    color: "#FFFFFF",
  },
  pickerContainer: {
    marginBottom: 16,
  },
  pickerLabel: {
    color: "#FFFFFF",
    marginBottom: 8,
  },
  buttonGroup: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  typeButton: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: "#333",
    borderRadius: 4,
    alignItems: "center",
    marginHorizontal: 4,
    backgroundColor: "#1E1E1E",
  },
  selectedButton: {
    backgroundColor: "#2196F3",
    borderColor: "#2196F3",
  },
  typeButtonText: {
    color: "#FFFFFF",
    fontSize: 12,
  },
  selectedButtonText: {
    fontWeight: "bold",
  },
  button: {
    backgroundColor: "#2196F3",
    height: 50,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 16,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
  loginText: {
    marginTop: 16,
    textAlign: "center",
    color: "#2196F3",
  },
})

export default SignUpScreen
