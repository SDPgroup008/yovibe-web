"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image, ActivityIndicator } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import FirebaseService from "../services/FirebaseService"
import { useAuth } from "../contexts/AuthContext"
import type { Event } from "../models/Event"
import type { EventsScreenProps } from "../navigation/types"

const EventsScreen: React.FC<EventsScreenProps> = ({ navigation }) => {
  const { user } = useAuth()
  const [events, setEvents] = useState<Event[]>([])
  const [featuredEvents, setFeaturedEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      loadEvents()
    })

    return unsubscribe
  }, [navigation])

  const loadEvents = async () => {
    try {
      setLoading(true)
      const allEvents = await FirebaseService.getEvents()
      setEvents(allEvents)

      const featured = await FirebaseService.getFeaturedEvents()
      setFeaturedEvents(featured)
    } catch (error) {
      console.error("Error loading events:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleEventSelect = (eventId: string) => {
    navigation.navigate("EventDetail", { eventId })
  }

  const handleAddEvent = () => {
    // Use type assertion to work around the navigation type limitations
    ;(navigation as any).navigate("AddEvent")
  }

  const renderEventItem = ({ item }: { item: Event }) => (
    <TouchableOpacity style={styles.eventCard} onPress={() => handleEventSelect(item.id)}>
      <Image source={{ uri: item.posterImageUrl }} style={styles.eventImage} />
      <View style={styles.eventContent}>
        <Text style={styles.eventName}>{item.name}</Text>
        <Text style={styles.eventVenue}>{item.venueName}</Text>
        <Text style={styles.eventDate}>{item.date.toDateString()}</Text>
        <View style={styles.artistsContainer}>
          {item.artists.map((artist, index) => (
            <Text key={index} style={styles.artistName}>
              {artist}
              {index < item.artists.length - 1 ? ", " : ""}
            </Text>
          ))}
        </View>
      </View>
    </TouchableOpacity>
  )

  return (
    <View style={styles.container}>
      {/* Add Event Button for Regular Users */}
      {user && (user.userType === "user" || user.userType === "admin") && (
        <TouchableOpacity style={styles.addEventButton} onPress={handleAddEvent}>
          <Ionicons name="add-circle-outline" size={20} color="#FFFFFF" />
          <Text style={styles.addEventButtonText}>Add New Event</Text>
        </TouchableOpacity>
      )}

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#2196F3" />
          <Text style={styles.loadingText}>Loading events...</Text>
        </View>
      ) : events.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No events found</Text>
          <Text style={styles.emptySubtext}>Check back later for upcoming events</Text>
        </View>
      ) : (
        <>
          {featuredEvents.length > 0 && (
            <View style={styles.featuredSection}>
              <Text style={styles.sectionTitle}>Featured Events</Text>
              <FlatList
                horizontal
                data={featuredEvents}
                keyExtractor={(item) => `featured-${item.id}`}
                renderItem={({ item }) => (
                  <TouchableOpacity style={styles.featuredCard} onPress={() => handleEventSelect(item.id)}>
                    <Image source={{ uri: item.posterImageUrl }} style={styles.featuredImage} />
                    <View style={styles.featuredOverlay}>
                      <Text style={styles.featuredName}>{item.name}</Text>
                      <Text style={styles.featuredVenue}>{item.venueName}</Text>
                      <Text style={styles.featuredDate}>{item.date.toDateString()}</Text>
                    </View>
                  </TouchableOpacity>
                )}
                showsHorizontalScrollIndicator={false}
              />
            </View>
          )}

          <Text style={styles.sectionTitle}>All Events</Text>
          <FlatList
            data={events}
            keyExtractor={(item) => item.id}
            renderItem={renderEventItem}
            ListEmptyComponent={<Text style={styles.emptyText}>No events found</Text>}
          />
        </>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#121212",
    padding: 16,
  },
  addEventButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#2196F3",
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
    justifyContent: "center",
  },
  addEventButtonText: {
    color: "#FFFFFF",
    fontWeight: "bold",
    marginLeft: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    color: "#FFFFFF",
    marginTop: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
  },
  emptySubtext: {
    color: "#999999",
    fontSize: 14,
    marginTop: 8,
    textAlign: "center",
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
  },
  featuredSection: {
    marginBottom: 24,
  },
  featuredCard: {
    width: 280,
    height: 180,
    marginRight: 16,
    borderRadius: 12,
    overflow: "hidden",
  },
  featuredImage: {
    width: "100%",
    height: "100%",
  },
  featuredOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: "rgba(0,0,0,0.6)",
  },
  featuredName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  featuredVenue: {
    fontSize: 14,
    color: "#2196F3",
    marginTop: 4,
  },
  featuredDate: {
    fontSize: 14,
    color: "#DDDDDD",
    marginTop: 4,
  },
  eventCard: {
    flexDirection: "row",
    backgroundColor: "#1E1E1E",
    borderRadius: 8,
    overflow: "hidden",
    marginBottom: 16,
  },
  eventImage: {
    width: 100,
    height: 120,
  },
  eventContent: {
    flex: 1,
    padding: 12,
  },
  eventName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  eventVenue: {
    fontSize: 16,
    color: "#2196F3",
    marginTop: 4,
  },
  eventDate: {
    fontSize: 14,
    color: "#BBBBBB",
    marginTop: 4,
  },
  artistsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: 4,
  },
  artistName: {
    fontSize: 14,
    color: "#DDDDDD",
  },
})

export default EventsScreen
